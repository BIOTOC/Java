package fa.training.assignment1;

public class ArithmeticExercise3 {
    public static void main(String[] args) {
        double result = ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
        System.out.println(result);
    }
}
