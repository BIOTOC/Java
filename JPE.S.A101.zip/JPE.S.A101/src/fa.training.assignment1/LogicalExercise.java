package fa.training.assignment1;

import java.util.Scanner;

public class LogicalExercise {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Input first integer: ");
        int first = sc.nextInt();
        System.out.print("Input second integer: ");
        int second = sc.nextInt();

        if(first != second) {
            System.out.println(first + " != " + second);
            if (first > second) {
                System.out.println(first + " > " + second);
                System.out.println(first + " >= " + second);
            } else if (first < second) {
                System.out.println(first + " < " + second);
                System.out.println(first + " <= " + second);
            }
        }else{
            System.out.println(first + " = " + second);
            if (first > second) {
                System.out.println(first + " > " + second);
                System.out.println(first + " >= " + second);
            } else if (first < second) {
                System.out.println(first + " < " + second);
                System.out.println(first + " <= " + second);
            }
        }
    }
}
