package fa.training.assignment1;

public class RectangleExercise {
    public static void main(String[] args) {

        //input và output bài này em thấy hơi sai
        //vì width khai báo là 5.5 nhưng ở output lại là 5.6
        double width = 5.5, height = 8.5;
        double area = width * height;
        double perimeter = (width + height) * 2;

        System.out.println("Area is " + width + " * " + height + " = " + area);
        System.out.println("Perimeter is 2 * (" + width + " + " + height + ") = " + perimeter);

    }
}
