package fa.training.assignment1;

public class CircleExercise {
    public static void main(String[] args) {

        double radius = 7.5;
        double perimeter = radius * 2 * Math.PI;
        double area = radius * radius * Math.PI;

        System.out.println("Perimeter is = " + perimeter);
        System.out.println("Area is = " + area);
    }
}
