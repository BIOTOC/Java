package fa.training.assignment1;



// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class ArithmeticExercise1 {
    public static void main(String[] args) {

        System.out.println(-5 +8 *6);
        System.out.println((55+9)%9);
        System.out.println(20 + -3*5/8);
        System.out.println(5 + 15/3 * 2 - 8 % 3);

    }


}