package fa.training.entities;

import fa.training.utils.Validator;
import java.util.Scanner;

public class Course {
    private String id, name;
    private double duration;
    private String status, flag;

    public Course() {
    }

    public Course(String id, String name, double duration, String status, String flag) {
        this.id = id;
        this.name = name;
        this.duration = duration;
        this.status = status;
        this.flag = flag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return id + ", " + name + ", " + duration + ", " + status  + ", " + flag;
    }

    public void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Course Code: ");
        this.id = Validator.checkCode();
        System.out.println("Enter Course Name: ");
        this.name = sc.nextLine();
        System.out.println("Enter Course Duration: ");
        this.duration = Validator.checkDuration();
        System.out.println("Enter Course Status (active, in-active): ");
        this.status = Validator.checkStatus();
        System.out.println("Enter Course Flag (optional, mandatory, N/A): ");
        this.flag = Validator.checkFlag();

    }



}
