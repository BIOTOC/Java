package fa.training.main;

import fa.training.entities.Course;
import fa.training.utils.Validator;

import java.util.Scanner;

public class CourseManagement {
    static Course[] courses = new Course[10];

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = 0;

        for (int i = 0; i < courses.length; i++) {
            Course course = new Course();
            n = i + 1;
            System.out.println("Course number " + n);
            course.input();
            courses[i] = course;
        }

//        courses[0] = new Course("FW111", "First", 6, "active", "mandatory");
//        courses[1] = new Course("FW222", "Second", 5, "in-active", "N/A");
//        courses[2] = new Course("FW333", "Third", 6, "in-active", "optional");

        System.out.println("All course: ");
        for (Course course : courses) {
            System.out.println(course);
        }

        System.out.println("\nAll course where flag = mandatory ");
        for (Course course : courses) {
            if(course.getFlag().equals("mandatory")){
                System.out.println(course);
            }
        }

        String type = "";

        System.out.println("\n");
        while (true){
            System.out.println("Enter type (id, name, duration, status, flag): ");
            type = sc.next();
            if(type.equals("id") || type.equals("name") || type.equals("duration") || type.equals("status") || type.equals("flag")){
                break;
            }
            else{
                System.err.println("Please enter 1 of 5 correct types (id, name, duration, status, flag)!");
            }
        }
        System.out.println("Enter data: ");
        Object value = null;

        if (type.equalsIgnoreCase("id")) {
            value = Validator.checkCode();
        }
        if (type.equalsIgnoreCase("name")) {
            value = sc.nextLine();
        }
        if (type.equalsIgnoreCase("duration")) {
            value = Validator.checkDuration();
        }
        if (type.equalsIgnoreCase("status")) {
            value = Validator.checkStatus();
        }
        if (type.equalsIgnoreCase("flag")) {
            value = Validator.checkFlag();
        }else{
            System.err.println();
        }


        find(type,  value);
    }

    public static void find(String type, Object data){
        switch (type){
            case "id":
                boolean checkid = false;
                for (Course course : courses) {
                    if (course.getId().equalsIgnoreCase((String) data)) {
                        checkid = true;
                        System.out.println(course);
                    }
                }
                if(!checkid){
                    System.err.println("There are no result with id = " + data.toString());
                }
                break;
            case "name":
                boolean checkname = false;
                for (Course course : courses) {
                    if (course.getName().equalsIgnoreCase((String) data)) {
                        checkname = true;
                        System.out.println(course);
                    }
                }
                if(!checkname){
                    System.err.println("There are no result with name = " + data.toString());
                }
                break;
            case "duration":
                boolean checkduration = false;
                for (Course course : courses) {
                    if (course.getDuration() == (double) data) {
                        checkduration = true;
                        System.out.println(course);
                    }
                }
                if(!checkduration){
                    System.err.println("There are no result with duration = " + data.toString());
                }
                break;
            case "status":
                boolean checkstatus = false;
                for (Course course : courses) {
                    if (course.getStatus().equalsIgnoreCase((String) data)) {
                        checkstatus = true;
                        System.out.println(course);
                    }
                }
                if(!checkstatus){
                    System.err.println("There are no result with status = " + data.toString());
                }
                break;
            case "flag":
                boolean checkflag = false;
                for (Course course : courses) {
                    if (course.getFlag().equalsIgnoreCase((String) data)) {
                        checkflag = true;
                        System.out.println(course);
                    }
                }
                if (!checkflag){
                    System.err.println("There are no result with flag = " + data.toString());
                }
                break;
        }
    }
}
