package fa.training.utils;

import java.util.Locale;
import java.util.Scanner;

public class Validator {
    static Scanner sc = new Scanner(System.in);

    public static String checkCode(){
        while (true){

            String code = sc.next();
            if(code.length()==5 && code.startsWith("FW")){
                return code;
            }else{
                System.err.println("Invalid Course Code. Please enter again!");
            }
        }
    }

    public static String checkStatus(){
        while (true){

            String status = sc.next();
            if(status.equalsIgnoreCase("active") || status.equalsIgnoreCase("in-active")){
                return status;
            }else {
                System.err.println("Invalid Course Status. Please enter again!");
            }
        }
    }

    public static String checkFlag(){
        while (true){

            String flag = sc.next();
            if(flag.equalsIgnoreCase("optional") || flag.equalsIgnoreCase("mandatory") || flag.equalsIgnoreCase("N/A")){
                return flag;
            }else{
                System.err.println("Invalid Course Flag. Please enter again!");
            }
        }
    }

    public static Double checkDuration(){
        while (true) {
            try {
                String duration = sc.next();
                return Double.parseDouble(duration);
            } catch (NumberFormatException e) {
                System.err.println("Invalid Course Duration. Please enter again!");
            }
        }
    }


}
